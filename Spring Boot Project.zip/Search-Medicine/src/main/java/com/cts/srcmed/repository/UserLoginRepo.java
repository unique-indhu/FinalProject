  package com.cts.srcmed.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.srcmed.model.User;

public interface UserLoginRepo extends JpaRepository<User, Integer> {
	public User findByUsername(String username);
}
