package com.cts.srcmed.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cts.srcmed.model.stock;
import com.cts.srcmed.repository.stockRepo;
import com.cts.srcmed.service.stockService;
@Service
public class stockServiceImpl implements stockService{
@Autowired
private stockRepo stockRepository;  
	@Override
	public void deleteStock(int StockId) {
		 stockRepository.deleteByStockId(StockId);
		
	}

	public List<stock> getAllStocks() {
		// TODO Auto-generated method stub
		return stockRepository.findAll();
	}
	@Override
	 public void updateStock(stock stock) {
	        stockRepository.save(stock);
	    }

	public List<stock> listAll(String keyword) {
		 if (keyword != null) {
	            return stockRepository.search(keyword);
	        }
	        return stockRepository.findAll();
	
	}
	
	
}

	