package com.cts.srcmed.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.Date;
import java.util.List;
import com.cts.srcmed.model.stock;


public interface stockRepo extends JpaRepository<stock, Integer> {
	
	 stock findByStockId(int stockId);
	    
	    List<stock> findByDrugName(String drugName);
	    
	    List<stock> findByCompany(String company);
	    List<stock> findByExpDateBefore(Date date);
	    void deleteByStockId(int stockId);
	    @Query("SELECT s FROM stock s WHERE CONCAT(s.stockId, ' ', s.stockLocId, ' ', s.drugName, ' ', s.company) LIKE %?1%")
	    public List<stock> search(String keyword);
}
