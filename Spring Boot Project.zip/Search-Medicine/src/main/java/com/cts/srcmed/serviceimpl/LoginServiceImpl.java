  package com.cts.srcmed.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.srcmed.model.User;
import com.cts.srcmed.repository.UserLoginRepo;
import com.cts.srcmed.service.LoginService;
@Service
public class LoginServiceImpl implements LoginService {
	@Autowired
    private UserLoginRepo userRepository;

	@Override
	public boolean authentication(String username, String password) {
        User User = userRepository.findByUsername(username);
        if (User != null && User.getPassword().equals(password)) {
            return true;
        }
        return false;

	}
	@Override
    public String getDesignation(String username) {
        User User = userRepository.findByUsername(username);
        if (User != null) {
            return User.getDesignation();
        }
        return null;
    }

	
	@Override
	public void saveUser(User User) {
		 userRepository.save(User);
		
	}
	
	
	@Override
	public boolean isUserAlreadyPresent(String username) {
	    User user = userRepository.findByUsername(username);
	    return user != null;
	}
}
