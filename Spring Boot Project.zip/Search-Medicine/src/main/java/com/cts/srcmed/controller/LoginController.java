package com.cts.srcmed.controller;

import com.cts.srcmed.model.User;
import com.cts.srcmed.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController {

    @Autowired
    private LoginService loginService;

    @GetMapping("/")
    public String home() {
        return "UserLogin";
    }

    @GetMapping("/login")
    public String login(@RequestParam("username") String username,
                        @RequestParam("password") String password, Model model) {

        boolean isAuthenticated = loginService.authentication(username, password);

        if (isAuthenticated) {
            String designation = loginService.getDesignation(username);
            model.addAttribute("designation", designation);

            if (designation.equalsIgnoreCase("Admin")) {
                return "adminPage";
            }

            return "welcome";
        } else {
            model.addAttribute("error", "Invalid username or password");
            return "UserLogin";
        }
    }

    @PostMapping("/login")
    public String loginUser(@ModelAttribute("user") User user, Model model) {

        boolean isAuthenticated = loginService.authentication(user.getUsername(), user.getPassword());

        if (isAuthenticated) {
            String designation = loginService.getDesignation(user.getUsername());
            model.addAttribute("designation", designation);

            if (designation.equalsIgnoreCase("Admin")) {
                return "adminPage";
            }

            return "welcome";
        } else {
            model.addAttribute("error", "Invalid username or password");
            return "UserLogin";
        }
    }

    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        User user = new User();
        model.addAttribute("user", user);
        return "register";
    }

    @PostMapping("/register")
    public String registerUser(@ModelAttribute("user") User user, Model model) {

        if (loginService.isUserAlreadyPresent(user.getUsername())) {
            model.addAttribute("error", "Username already exists");
            return "register";
        }

        loginService.saveUser(user);
        model.addAttribute("success", "User registered successfully");
        return "UserLogin";
    }

    @GetMapping("/logout")
    public String logout() {
        return "UserLogin";
    }
}