package com.cts.srcmed;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;


@SpringBootApplication
@ComponentScan({"com.cts.srcmed"})
public class srcmedApplication {

	public static void main(String[] args) {
		SpringApplication.run(srcmedApplication.class, args);
	}

}
