package com.cts.srcmed.service;

import com.cts.srcmed.model.User;

public interface LoginService {
	public void saveUser(User s);
	public boolean authentication(String username,String password);
	public String getDesignation(String username);
	boolean isUserAlreadyPresent(String username);
}
