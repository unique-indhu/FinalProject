package com.cts.srcmed.service;


import java.util.List;

import com.cts.srcmed.model.stock;

public interface stockService {
public void updateStock(stock stock); 
public void deleteStock(int StockId);
public static List<stock> getAllStocks() {
	// TODO Auto-generated method stub
	return null;
}
public static List<stock> listAll(String keyword) {
	// TODO Auto-generated method stub
	return null;
}

}
